﻿local ADDON, S = ...
S.Frames       = S.Frames or {}
S.Frames.Layout = S.Frames.Layout or {}

-- Compute layout & apply points/sizes; returns container width/height
function S.Frames.Layout.Apply(container, buttons, P)
    if not container or not buttons then return 0, 0 end
    P = P or {}

    local w     = tonumber(P.frameWidth)  or 120
    local h     = tonumber(P.frameHeight) or 28
    local pad   = tonumber(P.frameSpacing) or 2
    local orient= (P.orientation == "VERTICAL") and "VERTICAL" or "HORIZONTAL"
    local per   = (orient == "HORIZONTAL") and (tonumber(P.framesPerRow) or 5)
            or (tonumber(P.framesPerColumn) or 5)

    local total = #buttons
    local cols, rows
    if orient == "HORIZONTAL" then
        cols = math.min(per, total)
        rows = math.ceil(total / per)
    else
        rows = math.min(per, total)
        cols = math.ceil(total / per)
    end

    local contW = math.max(1, cols * w + (cols - 1) * pad)
    local contH = math.max(1, rows * h + (rows - 1) * pad)
    container:SetSize(contW, contH)

    for idx, btn in ipairs(buttons) do
        btn:SetSize(w, h)
        local r, col
        if orient == "HORIZONTAL" then
            r   = math.floor((idx - 1) / per)
            col = (idx - 1) % per
        else
            col = math.floor((idx - 1) / per)
            r   = (idx - 1) % per
        end
        local x = col * (w + pad)
        local y = -r * (h + pad)
        btn:ClearAllPoints()
        btn:SetPoint("TOPLEFT", container, "TOPLEFT", x, y)
    end

    return contW, contH
end
