﻿-- Frames/Updates.lua
-- Intentionally minimal/no-op for now; included for future expansion.
local ADDON, S = ...
S.Frames = S.Frames or {}
local U = {}
S.Frames.Updates = U
return U
