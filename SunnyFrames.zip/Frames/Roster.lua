﻿local ADDON, S = ...
S.Frames       = S.Frames or {}
S.Frames.Roster = S.Frames.Roster or {}

function S.Frames.Roster.BuildPartyList()
    local t = { "player" }
    for i = 1, 4 do
        local u = "party"..i
        if UnitExists(u) then table.insert(t, u) end
    end
    return t
end