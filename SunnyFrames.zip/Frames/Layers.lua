﻿local ADDON, S = ...
S.Frames        = S.Frames or {}
S.Frames.Layers = S.Frames.Layers or {}

local Layers = S.Frames.Layers

-- Ordered planes: low -> high. Insert anywhere, unlimited.
local ORDER = {
    "background",
    "healthBar",
    "shieldBar",
    "powerBar",
    "nameText",
}

local RANK   = {}
local STRIDE = 10   -- gap between planes; room to insert/nudge

local function rebuildRank()
    wipe(RANK)
    for i, name in ipairs(ORDER) do
        RANK[name] = i
    end
end
rebuildRank()

-- Public API -----------------------------------------------------------------

function Layers.GetOrder()
    local copy = {}
    for i, v in ipairs(ORDER) do copy[i] = v end
    return copy
end

function Layers.SetOrder(newOrder)
    if type(newOrder) ~= "table" or #newOrder == 0 then return end
    ORDER = {}
    for _, v in ipairs(newOrder) do
        if type(v) == "string" and v ~= "" then
            ORDER[#ORDER+1] = v
        end
    end
    rebuildRank()
    Layers.ApplyAll()
end

function Layers.SetStride(n)
    n = tonumber(n) or STRIDE
    if n < 1 then n = 1 end
    STRIDE = n
    Layers.ApplyAll()
end

-- Register a child frame as a named plane for btn
function Layers.RegisterPlane(btn, planeName, frame, offset)
    if not (btn and planeName and frame and frame.SetFrameLevel) then return end
    btn._sfPlanes = btn._sfPlanes or {}
    btn._sfPlanes[planeName] = { frame = frame, offset = math.floor(tonumber(offset) or 0) }
end

function Layers.UnregisterPlane(btn, planeName)
    if btn and btn._sfPlanes then
        btn._sfPlanes[planeName] = nil
    end
end

-- Apply to one button AFTER all planes are attached
function S.Frames.Layers.Apply(btn)
    if not (btn and btn._sfPlanes) then return end

    local ORDER   = S.Frames.Layers.GetOrder()  -- low -> high
    local RANK    = {}
    for i, name in ipairs(ORDER) do RANK[name] = i end

    local STRIDE  = S.Frames.Layers._stride or 20
    local strata  = btn:GetFrameStrata() or "MEDIUM"
    local base    = (btn:GetFrameLevel() or 1) + 200  -- big cushion above parent visuals

    -- First pass: normalize strata for all planes
    for plane, data in pairs(btn._sfPlanes) do
        if data.frame and data.frame.SetFrameStrata then
            data.frame:SetFrameStrata(strata)
        end
    end

    -- Second pass: assign deterministic levels
    local clamp = function(lvl)
        if lvl < 0 then return 0 end
        if lvl > 65535 then return 65535 end
        return lvl
    end

    for plane, data in pairs(btn._sfPlanes) do
        local idx = RANK[plane]
        if not idx then
            ORDER[#ORDER+1] = plane
            RANK[plane] = #ORDER
            idx = RANK[plane]
        end
        local lvl = base + idx * STRIDE + (data.offset or 0)
        if data.frame and data.frame.SetFrameLevel then
            data.frame:SetFrameLevel(clamp(lvl))
        end
    end

    -- Safety: nameText should always be above healthBar
    local name = btn._sfPlanes["nameText"]
    local hb   = btn._sfPlanes["healthBar"]
    if name and name.frame and hb and hb.frame then
        local nl = name.frame:GetFrameLevel() or 0
        local hl = hb.frame:GetFrameLevel() or 0
        if nl <= hl and name.frame.SetFrameLevel then
            name.frame:SetFrameLevel(clamp(hl + 5))
        end
    end
end


-- Reapply to every active button
function S.Frames.Layers.ApplyAll()
    local F = S.Frames.Factory
    if not F or not F.Active then return end
    local actives = F.Active()
    for _, btn in pairs(actives) do
        S.Frames.Layers.Apply(btn)
    end
end
