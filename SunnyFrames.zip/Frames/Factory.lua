﻿-- Frames/Factory.lua
local ADDON, S = ...
S.Frames = S.Frames or {}
local F = {}
S.Frames.Factory = F

local pool, active = {}, {}

local function makeName(i)
    return "SunnyFramesUnitFrame" .. i
end

local function CreateUnitFrame(i, parent)
    if S.dprintf then
        S.dprintf("Factory: creating frame #%d", i)
    end
    local name = makeName(i)
    local f = CreateFrame("Button", name, parent, "SecureUnitButtonTemplate,BackdropTemplate")

    f:EnableMouse(true)
    
    f:SetBackdrop({ bgFile = "Interface/Buttons/WHITE8x8", edgeFile = "Interface/Buttons/WHITE8x8", edgeSize = 1 })
    f:SetBackdropColor(0.12, 0.12, 0.12, 0.8)
    f:SetBackdropBorderColor(0, 0, 0, 1)

    local health = CreateFrame("StatusBar", nil, f)
    health:SetPoint("TOPLEFT", 1, -1)
    health:SetPoint("BOTTOMRIGHT", -1, 1)
    health:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    health:SetFrameLevel(f:GetFrameLevel()) 
    health:GetStatusBarTexture():SetDrawLayer("BORDER")
    f.Health = health

    if health.EnableMouse then health:EnableMouse(false) end
    local tex = health:GetStatusBarTexture()
    if tex and tex.EnableMouse then tex:EnableMouse(false) end
    
    local healthBG = f:CreateTexture(nil, "BACKGROUND")
    healthBG:SetAllPoints(health)
    healthBG:SetColorTexture(0.1, 0.1, 0.1, 1)
    f.HealthBG = healthBG

    local fs = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    fs:SetPoint("CENTER")
    fs:SetText("")
    fs:SetDrawLayer("OVERLAY")
    f.NameText = fs

    -- Apply click behavior according to settings
    if S.Frames and S.Frames.ApplyClickTargeting then
        S.Frames.ApplyClickTargeting(f)
    else
        f:RegisterForClicks("AnyUp")
        f:SetAttribute("type1", "target")
        f:SetAttribute("type2", "togglemenu")
    end
    return f
end

function F.EnsurePool(parent, count)
    for i = 1, count do
        if not pool[i] then
            pool[i] = CreateUnitFrame(i, parent);
            pool[i]:Hide()
        else
            pool[i]:SetParent(parent)
        end
    end
end

function F.Acquire(i, parent)
    if S.dprintf then
        S.dprintf("Factory: acquire #%d", i)
    end
    local f = pool[i] or CreateUnitFrame(i, parent);
    pool[i] = f
    f:SetParent(parent);
    f:Show();
    active[i] = f;
    return f
end

function F.HideUnused(fromIndex)
    for i = fromIndex, #pool do
        if pool[i] then
            pool[i]:Hide()
        end
    end
    for i = fromIndex, #active do
        active[i] = nil
    end
end

function F.Active()
    return active
end

-- Creates (once) and reapplies a crisp, pixel-perfect border around a unit button.
function S.Frames_ApplyPixelBorder(btn)
    if not btn then return end

    -- Build border textures once
    if not btn._sborder then
        local LAYER = "OVERLAY"
        local parent = btn

        local t = {}
        t.top    = parent:CreateTexture(nil, LAYER)
        t.bottom = parent:CreateTexture(nil, LAYER)
        t.left   = parent:CreateTexture(nil, LAYER)
        t.right  = parent:CreateTexture(nil, LAYER)

        t.top:SetColorTexture(0,0,0,1)
        t.bottom:SetColorTexture(0,0,0,1)
        t.left:SetColorTexture(0,0,0,1)
        t.right:SetColorTexture(0,0,0,1)

        btn._sborder = t
    end

    local t = btn._sborder
    local cfg  = S.Profile and S.Profile.frames or {}
    local raw  = tonumber(cfg.frameBorder) or 1 -- desired logical thickness (in UI units before snapping)

    -- Snap thickness to whole pixels at the button's effective scale
    local px, snap = S.UI_GetPixel(btn)
    local th = snap(raw)
    if th <= 0 then
        -- Hide all if turned off
        t.top:Hide(); t.bottom:Hide(); t.left:Hide(); t.right:Hide()
        return
    end

    -- Border color (you can later expose this if you want)
    local br, bg, bb, ba = 0, 0, 0, 1

    -- Expand a hair outward so the inner content isn’t compressed when thickness grows
    local OUT = snap(0.0)

    -- Top
    t.top:ClearAllPoints()
    t.top:SetPoint("TOPLEFT",   btn, "TOPLEFT",   -OUT,  OUT)
    t.top:SetPoint("TOPRIGHT",  btn, "TOPRIGHT",   OUT,  OUT)
    t.top:SetHeight(th)
    t.top:SetColorTexture(br, bg, bb, ba)
    t.top:Show()

    -- Bottom
    t.bottom:ClearAllPoints()
    t.bottom:SetPoint("BOTTOMLEFT",  btn, "BOTTOMLEFT", -OUT, -OUT)
    t.bottom:SetPoint("BOTTOMRIGHT", btn, "BOTTOMRIGHT",  OUT, -OUT)
    t.bottom:SetHeight(th)
    t.bottom:SetColorTexture(br, bg, bb, ba)
    t.bottom:Show()

    -- Left
    t.left:ClearAllPoints()
    t.left:SetPoint("TOPLEFT",     btn, "TOPLEFT",    -OUT,  OUT)
    t.left:SetPoint("BOTTOMLEFT",  btn, "BOTTOMLEFT", -OUT, -OUT)
    t.left:SetWidth(th)
    t.left:SetColorTexture(br, bg, bb, ba)
    t.left:Show()

    -- Right
    t.right:ClearAllPoints()
    t.right:SetPoint("TOPRIGHT",    btn, "TOPRIGHT",   OUT,  OUT)
    t.right:SetPoint("BOTTOMRIGHT", btn, "BOTTOMRIGHT",OUT, -OUT)
    t.right:SetWidth(th)
    t.right:SetColorTexture(br, bg, bb, ba)
    t.right:Show()
end

-- Refresh *all* visible buttons’ borders (called by the notifier).
function S.Frames_RefreshAllBorders()
    if not S or not S.Frames or not S.Frames.Manager or not S.Frames.Manager.IterateButtons then return end
    for btn in S.Frames.Manager.IterateButtons("party") do
        S.Frames_ApplyPixelBorder(btn)
    end
    -- If you also have raid buttons already, call IterateButtons("raid") the same way.
end

-- Wire into your Elements table so Notify("frames") can repaint borders too.
S.Frames = S.Frames or {}
S.Frames.Elements = S.Frames.Elements or {}
S.Frames.Elements.Border = {
    RefreshAll = S.Frames_RefreshAllBorders
}
